package net.heartbeat.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.network.chat.Component;

public class ToastUtil {
    public static void showUpdatedToast(String name){
        Minecraft client = Minecraft.getInstance();

        SystemToast.add(
                client.gui.toastManager(),
                SystemToast.SystemToastId.PACK_COPY_FAILURE,
                Component.translatable("gui.heartbeat.title.updated"),
                Component.translatable("gui.heartbeat.description.updated", name)
        );
    }

    public static void showErrorToast(String name){
        Minecraft client = Minecraft.getInstance();

        SystemToast.add(
                client.gui.toastManager(),
                SystemToast.SystemToastId.PACK_COPY_FAILURE,
                Component.translatable("gui.heartbeat.title.failure"),
                Component.translatable("gui.heartbeat.description.failure", name)
        );
    }
}
